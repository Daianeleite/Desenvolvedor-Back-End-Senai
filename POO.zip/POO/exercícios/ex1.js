const readline = require("readline-sync");
const fs = require("fs");


class Pessoa {
    nome;
    idade;
    peso;
    altura;

    constructor(pNome, pIdade, pPeso, pAltura) {
        this.nome = pNome;
        this.idade = pIdade;
        this.peso = pPeso;
        this.altura = pAltura;

    }

    calcularImc() {
        return (this.peso/(this.altura*this.altura));

    }
}

let nomePessoa = readline.question("Digite seu nome:");
let idadePessoa = readline.questionInt("Digite sua idade:");
let pesoPessoa = readline.questionFloat("Digite seu peso:");
let alturaPessoa = readline.questionFloat("Digite sua altura:");

let pessoa = new Pessoa(nomePessoa, idadePessoa, pesoPessoa, alturaPessoa);

console.log ("Seu IMC é", pessoa.calcularImc());

