const readline = require ("readline-sync");
const fs = require ("fs");
const caminhoArquivo = './tarefas.json';

class Tarefas{
    _nome; //anderline faz com que o atributo seja privado por convenção
    _data;
    _status;
    _caminhoArquivo;

    constructor (pNome, pData, pStatus, pCaminhoArquivo){ //parâmetros 
        this._nome = pNome; //this = dentro desta classe eu tenho esse conteúdo
        this._data = pData;
        this._status = pStatus;
        this._caminhoArquivo = pCaminhoArquivo;

    }

    criarArquivo(){
        if(!fs.existsSync(this._caminhoArquivo)){
            try {
                fs.writeFileSync(this._caminhoArquivo, '[]');
            } catch (error) {
                console.error('Erro ao criar o arquivo;' , error);
            }
        }
    }

}

let nomeTarefa = readline.question("Digite o nome da tarefa:");
let dataTarefa = readline.question("Digite a data de conclusão da tarefa:");

let tarefa = new Tarefas (nomeTarefa, dataTarefa, 'Não concluído', caminhoArquivo);
tarefa.criarArquivo();

if(!fs.existsSync(caminhoArquivo)){

     console.log ("ARQUIVO NÃO FOI CRIADO");

} else {
    console.log("MÉTODO EXECUTADO COM SUCESSO!");
}
