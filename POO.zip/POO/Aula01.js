class Tarefas{
    nome;
    data;
    status;
}

let tarefa = new Tarefas();

tarefa.nome = "Programar";
tarefa.data = "Todos os dias";
tarefa.status = "Não concluído";

console.log(tarefa);